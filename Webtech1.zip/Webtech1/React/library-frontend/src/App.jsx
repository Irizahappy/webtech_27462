
import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

import "./App.css";

import Office from "./component/Office";
import OfficeList from "./component/OfficeList";

function App() {
  return (
    <BrowserRouter>

      <div style={{ padding: "20px" }}>

        <nav style={{ marginBottom: "20px" }}>
          <Link to="/office">Office Management</Link>

          {" | "}

          <Link to="/offices">View All Offices</Link>
        </nav>

        <Routes>
          <Route path="/" element={<Office />} />

          <Route path="/office" element={<Office />} />

          <Route path="/offices" element={<OfficeList />} />
          
        </Routes>

      </div>

    </BrowserRouter>
  );
}

export default App;
