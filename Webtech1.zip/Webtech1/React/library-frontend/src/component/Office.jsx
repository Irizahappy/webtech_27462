
import React, { useState } from "react";
import axios from "axios";
import LibraryButton from "./LibraryButton";

function Office() {

  // State for saving an office
  const [name, setName] = useState("");
  const [officeNumber, setOfficeNumber] = useState("");

  // State for deleting an office
  const [deleteNumber, setDeleteNumber] = useState("");

  // Save Office
  async function saveOffice() {

    if (name.trim() === "" || officeNumber.trim() === "") {
      alert("Please fill in all fields");
      return;
    }

    try {
      await axios.post(
        "http://localhost:8082/api/offices",
        {
          name: name,
          officeNumber: officeNumber
        }
      );

      alert("Office saved successfully!");

      setName("");
      setOfficeNumber("");

    } catch (error) {
      console.error(error);
      alert("Failed to save office");
    }
  }

  // Delete Office by Office Number
  async function deleteOffice() {

    if (deleteNumber.trim() === "") {
      alert("Please enter an office number");
      return;
    }

    const confirmDelete = window.confirm(
      "Are you sure you want to delete office " +
      deleteNumber + "?"
    );

    if (!confirmDelete) {
      return;
    }

    try {
      await axios.delete(
        "http://localhost:8082/api/offices/number/" +
        encodeURIComponent(deleteNumber.trim())
      );

      alert("Office deleted successfully!");

      setDeleteNumber("");

    } catch (error) {
      console.error(error);
      alert("Failed to delete office");
    }
  }

  return (
    <div style={{ padding: "30px" }}>

      {/* Save Office Section */}
      <div style={{
        padding: "20px",
        marginBottom: "30px"
        }}>

        <h2>Save Office</h2>

        <label>Office Name: </label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter office name"
        />

        <br /><br />

        <label>Office Number: </label>
        <input
          type="text"
          value={officeNumber}
          onChange={(e) => setOfficeNumber(e.target.value)}
          placeholder="Enter office number"
        />

        <br /><br />

        <LibraryButton
          buttonLabel="SAVE OFFICE"
          onClickButton={saveOffice}
        />

      </div>

      {/* Delete Office Section */}
      <div style={{
        padding: "20px"
        }}>

        <h2>Delete Office</h2>

        <label>Office Number: </label>
        <input
          type="text"
          value={deleteNumber}
          onChange={(e) => setDeleteNumber(e.target.value)}
          placeholder="Enter office number to delete"
        />

        <br /><br />

        <LibraryButton
          buttonLabel="DELETE OFFICE"
          onClickButton={deleteOffice}
        />

      </div>

    </div>
  );
}

export default Office;
