import React from 'react'
import LibraryCards from './LibraryCards.jsx'

function LibraryBooks() {
    const books = [
        {
            code:"WEB 001",
            name:"Introduction to Web Development",
            price: 1000,
        },
        {
            code:"CS 001",
            name:"Introduction to Computer Science",
            price: 1200,
        },
        {
            code:"SE 001",
            name:"Introduction to Software Engineering",
            price: 1500,
        }
    ];
    const totalBooks = books.length;
    const totalAmount = books.reduce((total, book) => total + book.price, 0);
  return (
    <div>
        <h2>List of books</h2>
        <ul>
             {
                books.map(book => <LibraryCards bookInfo={book}/>)
            }
        </ul>
        <p>The total price for {totalBooks} books is {totalAmount}</p>
    </div>
  )
}

export default LibraryBooks
