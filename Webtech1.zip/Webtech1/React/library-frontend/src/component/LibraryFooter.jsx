import React from 'react'

function LibraryFooter() {
  return (
    <div>
      www.auca.ac.rw @2026
    </div>
  )
}

export default LibraryFooter
