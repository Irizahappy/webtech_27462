import React from 'react'

function LibraryHeader() {
  return (
    <div>
      <h1>Library System</h1>
      <p>This is library system that will help you to manage the books</p>
    </div>
  )
}

export default LibraryHeader
