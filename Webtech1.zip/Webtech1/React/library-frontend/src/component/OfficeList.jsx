
import React, { useState, useEffect } from "react";
import axios from "axios";

function OfficeList() {

  const [offices, setOffices] = useState([]);
  const [search, setSearch] = useState("");

  // Get all offices from Spring Boot
  async function getOffices() {
    try {
      const response = await axios.get(
        "http://localhost:8082/api/offices"
      );

      setOffices(response.data);

    } catch (error) {
      console.error(error);
      alert("Failed to load offices");
    }
  }

  // Load offices when the page opens
  useEffect(() => {
    getOffices();
  }, []);

  // Delete office by office number
  async function deleteOffice(officeNumber) {

    const confirmDelete = window.confirm(
      "Are you sure you want to delete office " +
      officeNumber + "?"
    );

    if (!confirmDelete) {
      return;
    }

    try {
      await axios.delete(
        "http://localhost:8082/api/offices/number/" +
        encodeURIComponent(officeNumber)
      );

      alert("Office deleted successfully");

      // Refresh the office list
      getOffices();

    } catch (error) {
      console.error(error);
      alert("Failed to delete office");
    }
  }

  // Search by office name or office number
  const filteredOffices = offices.filter((office) => {

    const officeName = (office.name || "").toLowerCase();
    const officeNumber = String(
      office.officeNumber || ""
    ).toLowerCase();

    const searchText = search.toLowerCase();

    return (
      officeName.includes(searchText) ||
      officeNumber.includes(searchText)
    );
  });

  return (
    <div style={{ padding: "30px" }}>

      <h2>Office List</h2>

      {/* Search Section */}
      <input
        type="text"
        placeholder="Search by office name or number"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{
          padding: "10px",
          width: "300px",
          marginBottom: "20px"
        }}
      />

      {/* Office Table */}
      <table
        border="1"
        cellPadding="12"
        style={{
          width: "100%",
          borderCollapse: "collapse"
        }}
      >
        <thead>
          <tr>
            <th>ID</th>
            <th>Office Number</th>
            <th>Office Name</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {filteredOffices.map((office, index) => (
            <tr key={office.id}>

              <td>{index + 1}</td>

              <td>{office.officeNumber}</td>

              <td>{office.name}</td>

              <td>
                <button
                  onClick={() =>
                    deleteOffice(office.officeNumber)
                  }
                >
                  Delete
                </button>

                {" "}

                <button disabled>
                  Update
                </button>
              </td>

            </tr>
          ))}
        </tbody>
      </table>

      {filteredOffices.length === 0 && (
        <p>No offices found.</p>
      )}

    </div>
  );
}

export default OfficeList;
