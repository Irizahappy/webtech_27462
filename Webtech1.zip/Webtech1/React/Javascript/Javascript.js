function getOddNumbers(numbers){
    return numbers.filter(number=>number%2!==0);
}

function multiplyingOddNumbers(oddNumbers){
    return oddNumbers.reduce((total,number)=> total*number,1)
}

let numbers = [1,2,3,4,5,6,7,8,9];
let oddNumbers = getOddNumbers(numbers);
let multiplication = multiplyingOddNumbers(oddNumbers);

console.log("Odd Numbers:", oddNumbers);
console.log("Multiplication:", multiplication);