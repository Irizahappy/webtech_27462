
package auca.ac.clinicsystem.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import auca.ac.clinicsystem.model.Doctor;
import auca.ac.clinicsystem.model.Office;

public interface DoctorRepository extends JpaRepository<Doctor, UUID> {

    Optional<Doctor> findByOffice(Office office);

    boolean existsByOfficeAndIdNot(Office office, UUID doctorId);

    @Query("SELECT DISTINCT d FROM Doctor d " +
           "JOIN d.specializations s " +
           "WHERE LOWER(s.name) = LOWER(:name)")
    List<Doctor> findBySpecializationName(@Param("name") String name);

    @Query("SELECT d FROM Doctor d " +
           "WHERE d.office IS NULL " +
           "ORDER BY d.lastName ASC")
    List<Doctor> findDoctorsWithoutOffice();

    @Query("SELECT d FROM Doctor d " +
           "WHERE LOWER(d.firstName) LIKE LOWER(CONCAT('%', :name, '%')) " +
           "OR LOWER(d.lastName) LIKE LOWER(CONCAT('%', :name, '%')) " +
           "ORDER BY d.lastName ASC, d.firstName ASC")
    List<Doctor> searchDoctorsByName(@Param("name") String name);
}
