
package auca.ac.clinicsystem.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import auca.ac.clinicsystem.model.Appointment;
import auca.ac.clinicsystem.model.AppointmentStatus;
import auca.ac.clinicsystem.model.Doctor;
import auca.ac.clinicsystem.model.Office;
import auca.ac.clinicsystem.model.Specialization;
import auca.ac.clinicsystem.repository.AppointmentRepository;
import auca.ac.clinicsystem.repository.DoctorRepository;
import auca.ac.clinicsystem.repository.OfficeRepository;
import auca.ac.clinicsystem.repository.SpecializationRepository;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private OfficeRepository officeRepository;

    @Autowired
    private SpecializationRepository specializationRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    public Doctor getDoctorById(UUID id) {
        return doctorRepository.findById(id).orElse(null);
    }

    public Doctor createDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }

    public Doctor updateDoctor(UUID id, Doctor updatedDoctor) {
        Doctor doctor = doctorRepository.findById(id).orElse(null);

        if (doctor == null) {
            return null;
        }

        doctor.setFirstName(updatedDoctor.getFirstName());
        doctor.setLastName(updatedDoctor.getLastName());
        doctor.setPhoneNumber(updatedDoctor.getPhoneNumber());

        return doctorRepository.save(doctor);
    }

    public void deleteDoctor(UUID id) {
        doctorRepository.deleteById(id);
    }

    public List<Doctor> findBySpecialization(String name) {
        return doctorRepository.findBySpecializationName(name);
    }

    public List<Doctor> findDoctorsWithoutOffice() {
        return doctorRepository.findDoctorsWithoutOffice();
    }

    public String assignOffice(UUID doctorId, UUID officeId) {
        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);

        if (doctor == null) {
            return "No doctor found with id " + doctorId;
        }

        Office office = officeRepository.findById(officeId).orElse(null);

        if (office == null) {
            return "No office found with id " + officeId;
        }

        Optional<Doctor> existingOccupant = doctorRepository.findByOffice(office);

        if (existingOccupant.isPresent()
                && !existingOccupant.get().getId().equals(doctorId)) {
            return "Office " + officeId + " is already assigned to another doctor";
        }

        doctor.setOffice(office);
        doctorRepository.save(doctor);

        return "Office assigned successfully";
    }

    public String addSpecialization(UUID doctorId, UUID specializationId) {
        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);

        if (doctor == null) {
            return "The doctor with that id does not exist";
        }

        Specialization specialization = specializationRepository.findById(specializationId).orElse(null);

        if (specialization == null) {
            return "That specialization does not exist";
        }

        if (doctor.getSpecializations().contains(specialization)) {
            return "The doctor already has that specialization";
        }

        doctor.getSpecializations().add(specialization);
        doctorRepository.save(doctor);

        return "Specialization added to the doctor";
    }

    public String removeSpecialization(UUID doctorId, UUID specializationId) {
        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);

        if (doctor == null) {
            return "The doctor with that id does not exist";
        }

        Specialization specialization = specializationRepository.findById(specializationId).orElse(null);

        if (specialization == null) {
            return "That specialization does not exist";
        }

        if (!doctor.getSpecializations().contains(specialization)) {
            return "The doctor does not have that specialization";
        }

        doctor.getSpecializations().remove(specialization);
        doctorRepository.save(doctor);

        return "Specialization removed from the doctor";
    }

    public String changeOffice(UUID doctorId, String officeNumber) {
        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);

        if (doctor == null) {
            return "The doctor with that id does not exist";
        }

        Office office = officeRepository.findByRoomNumber(officeNumber).orElse(null);

        if (office == null) {
            return "The office with that office number does not exist";
        }

        if (doctorRepository.existsByOfficeAndIdNot(office, doctorId)) {
            return "That office is taken by other doctor";
        }

        doctor.setOffice(office);
        doctorRepository.save(doctor);

        return "Office changed successfully";
    }

    public List<Appointment> getDoctorAgenda(UUID doctorId, LocalDate date) {
        return appointmentRepository.findByDoctorIdAndAppointmentDateAndStatusNotOrderByAppointmentDateAsc(
                doctorId,
                date,
                AppointmentStatus.CANCELLED
        );
    }

    public List<Doctor> searchDoctorsByName(String name) {
        return doctorRepository.searchDoctorsByName(name);
    }
}
