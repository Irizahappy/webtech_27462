
package auca.ac.clinicsystem.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import auca.ac.clinicsystem.model.Office;
import auca.ac.clinicsystem.repository.OfficeRepository;

@Service
public class OfficeService {

    @Autowired
    private OfficeRepository officeRepository;

    public List<Office> getAllOffices() {
        return officeRepository.findAll();
    }

    public Office getOfficeById(UUID id) {
        return officeRepository.findById(id).orElse(null);
    }

    public Office createOffice(Office office) {
        return officeRepository.save(office);
    }

    public Office updateOffice(UUID id, Office updatedOffice) {
        Office office = officeRepository.findById(id).orElse(null);

        if (office == null) {
            return null;
        }

        office.setName(updatedOffice.getName());
        office.setOfficeNumber(updatedOffice.getOfficeNumber());

        return officeRepository.save(office);
    }

    public void deleteOffice(UUID id) {
        officeRepository.deleteById(id);
    }

    public Object getBusiestOffice() {
        List<Object[]> results = officeRepository.findBusiestOffice(
                PageRequest.of(0, 1)
        );

        if (results.isEmpty()) {
            return "No appointments yet";
        }

        return results.get(0);
    }

    public List<Office> findFreeOffices() {
        return officeRepository.findFreeOffices();
    }

    public void deleteOfficeByOfficeNumber(String officeNumber) {
        Office office = officeRepository
        .findByOfficeNumber(officeNumber)
        .orElseThrow(() -> new RuntimeException("Office not found"));
    officeRepository.delete(office);
}

}
