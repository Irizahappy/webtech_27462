
package auca.ac.clinicsystem.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import auca.ac.clinicsystem.model.Appointment;
import auca.ac.clinicsystem.model.AppointmentStatus;
import auca.ac.clinicsystem.service.AppointmentService;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @GetMapping
    public List<Appointment> getAllAppointments() {
        return appointmentService.getAllAppointments();
    }

    @GetMapping("/{id}")
    public Appointment getAppointmentById(@PathVariable UUID id) {
        return appointmentService.getAppointmentById(id);
    }

    @GetMapping("/by-status")
    public List<Appointment> getAppointmentsByStatus(
            @RequestParam AppointmentStatus status) {
        return appointmentService.getAppointmentsByStatus(status);
    }

    @GetMapping("/between")
    public List<Appointment> findBetween(
            @RequestParam String start,
            @RequestParam String end) {

        LocalDate startDate = LocalDate.parse(start);
        LocalDate endDate = LocalDate.parse(end);

        return appointmentService.findBetween(startDate, endDate);
    }

    @GetMapping("/stats/by-status")
    public List<Object[]> getAppointmentStatsByStatus() {
        return appointmentService.getAppointmentStatsByStatus();
    }

    @PatchMapping("/cancel-day")
    public String cancelAppointmentsForDay(
            @RequestParam UUID doctorId,
            @RequestParam String date) {

        LocalDate appointmentDate = LocalDate.parse(date);

        return appointmentService.cancelAppointmentsForDay(
                doctorId,
                appointmentDate
        );
    }

    @PostMapping
    public ResponseEntity<?> createAppointment(
            @RequestBody AppointmentRequest request) {

        if (request.getAppointmentDate() == null
                || request.getAppointmentDate().isBefore(LocalDate.now())) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body("Appointment date cannot be in the past");
        }

        Appointment appointment = appointmentService.createAppointment(
                request.getDoctorId(),
                request.getPatientId(),
                request.getAppointmentDate(),
                request.getReason(),
                request.getStatus()
        );

        if (appointment == null) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body("Unable to create appointment. Check doctor, patient and date");
        }

        return ResponseEntity.ok(appointment);
    }

    @PostMapping("/save")
    public ResponseEntity<String> saveAppointment(
            @RequestBody Appointment appointment) {

        String result = appointmentService.saveAppointment(appointment);

        if (result.equals("Appointment date cannot be in the past")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }

        if (result.equals("The doctor with that id does not exist")
                || result.equals("The patient with that id does not exist")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        }

        if (result.equals("Doctor is already booked on that date")) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(result);
        }

        return ResponseEntity.ok(result);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateAppointment(
            @PathVariable UUID id,
            @RequestBody AppointmentRequest request) {

        String result = appointmentService.updateAppointment(
                id,
                request.getAppointmentDate(),
                request.getReason(),
                request.getStatus()
        );

        if (result.equals("The appointment with that id does not exist")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        }

        if (result.equals("Appointment date cannot be in the past")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }

        if (result.equals("Doctor is already booked on that date")) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(result);
        }

        return ResponseEntity.ok(result);
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<String> changeAppointmentStatus(
            @PathVariable UUID id,
            @RequestParam AppointmentStatus status) {

        String result = appointmentService.changeAppointmentStatus(id, status);

        if (result.equals("The appointment with that id does not exist")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        }

        if (result.startsWith("Cannot change status from")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }

        return ResponseEntity.ok(result);
    }

    @PatchMapping("/{id}/reschedule")
    public ResponseEntity<String> rescheduleAppointment(
            @PathVariable UUID id,
            @RequestParam LocalDate newDate) {

        String result = appointmentService.rescheduleAppointment(id, newDate);

        if (result.equals("The appointment with that id does not exist")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        }

        if (result.equals("Doctor is already booked on that date")) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(result);
        }

        if (result.equals("Appointment date cannot be in the past")
                || result.endsWith("appointment cannot be rescheduled")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }

        return ResponseEntity.ok(result);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAppointment(@PathVariable UUID id) {

        String result = appointmentService.deleteAppointment(id);

        if (result.equals("The appointment with that id does not exist")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        }

        if (result.equals("That appointment has prescriptions, delete them first")) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(result);
        }

        return ResponseEntity.ok(result);
    }

    @GetMapping("/doctor/{doctorId}/scheduled")
    public List<Appointment> getScheduledOfDoctor(
            @PathVariable UUID doctorId) {

        return appointmentService
                .getScheduledAppointmentsOfDoctor(doctorId);
    }

    @GetMapping("/scheduled/overdue")
    public List<Object[]> getOverdueScheduled() {
        return appointmentService.getOverdueScheduledAppointments();
    }

    @GetMapping("/specialization/{name}")
    public List<Appointment> getBySpecialization(
            @PathVariable String name) {

        return appointmentService
                .getAppointmentsBySpecialization(name);
    }

    static class AppointmentRequest {

        private UUID doctorId;
        private UUID patientId;
        private LocalDate appointmentDate;
        private String reason;
        private AppointmentStatus status;

        public UUID getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(UUID doctorId) {
            this.doctorId = doctorId;
        }

        public UUID getPatientId() {
            return patientId;
        }

        public void setPatientId(UUID patientId) {
            this.patientId = patientId;
        }

        public LocalDate getAppointmentDate() {
            return appointmentDate;
        }

        public void setAppointmentDate(LocalDate appointmentDate) {
            this.appointmentDate = appointmentDate;
        }

        public String getReason() {
            return reason;
        }

        public void setReason(String reason) {
            this.reason = reason;
        }

        public AppointmentStatus getStatus() {
            return status;
        }

        public void setStatus(AppointmentStatus status) {
            this.status = status;
        }
    }
}
