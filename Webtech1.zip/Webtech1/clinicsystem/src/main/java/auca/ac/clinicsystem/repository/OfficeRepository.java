
package auca.ac.clinicsystem.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import auca.ac.clinicsystem.model.Office;

public interface OfficeRepository extends JpaRepository<Office, UUID> {

    Optional<Office> findByOfficeNumber(String officeNumber);

    @Query("SELECT o.officeNumber, COUNT(a) " +
           "FROM Appointment a " +
           "JOIN a.doctor d " +
           "JOIN d.office o " +
           "GROUP BY o.id, o.officeNumber " +
           "ORDER BY COUNT(a) DESC")
    List<Object[]> findBusiestOffice(Pageable pageable);

    @Query("SELECT o FROM Office o " +
           "WHERE NOT EXISTS " +
           "(SELECT d FROM Doctor d WHERE d.office = o) " +
           "ORDER BY o.officeNumber ASC")
    List<Office> findFreeOffices();
}
