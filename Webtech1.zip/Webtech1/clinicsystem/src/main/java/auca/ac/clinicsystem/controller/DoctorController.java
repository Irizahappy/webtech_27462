
package auca.ac.clinicsystem.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import auca.ac.clinicsystem.model.Appointment;
import auca.ac.clinicsystem.model.Doctor;
import auca.ac.clinicsystem.service.DoctorService;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {

    @Autowired
    private DoctorService doctorService;

    @GetMapping
    public List<Doctor> getAllDoctors() {
        return doctorService.getAllDoctors();
    }

    @GetMapping("/{id}")
    public Doctor getDoctorById(@PathVariable UUID id) {
        return doctorService.getDoctorById(id);
    }

    @GetMapping("/by-specialization")
    public List<Doctor> findBySpecialization(@RequestParam String name) {
        return doctorService.findBySpecialization(name);
    }

    @GetMapping("/without-office")
    public List<Doctor> findDoctorsWithoutOffice() {
        return doctorService.findDoctorsWithoutOffice();
    }

    @PostMapping
    public Doctor createDoctor(@RequestBody Doctor doctor) {
        return doctorService.createDoctor(doctor);
    }

    @PutMapping("/{id}")
    public Doctor updateDoctor(@PathVariable UUID id, @RequestBody Doctor doctor) {
        return doctorService.updateDoctor(id, doctor);
    }

    @DeleteMapping("/{id}")
    public void deleteDoctor(@PathVariable UUID id) {
        doctorService.deleteDoctor(id);
    }

    @PutMapping("/{doctorId}/office/{officeId}")
    public ResponseEntity<?> assignOffice(
            @PathVariable UUID doctorId,
            @PathVariable UUID officeId) {

        String result = doctorService.assignOffice(doctorId, officeId);

        if (result.startsWith("No doctor found")
                || result.startsWith("No office found")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        }

        if (result.contains("already assigned")) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(result);
        }

        return ResponseEntity.ok(result);
    }

    @PutMapping("/{doctorId}/specializations/{specializationId}")
    public ResponseEntity<?> addSpecialization(
            @PathVariable UUID doctorId,
            @PathVariable UUID specializationId) {

        String result = doctorService.addSpecialization(doctorId, specializationId);

        if (result.equals("The doctor with that id does not exist")
                || result.equals("That specialization does not exist")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        }

        if (result.equals("The doctor already has that specialization")) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(result);
        }

        return ResponseEntity.ok(result);
    }

    @DeleteMapping("/{doctorId}/specializations/{specializationId}")
    public ResponseEntity<?> removeSpecialization(
            @PathVariable UUID doctorId,
            @PathVariable UUID specializationId) {

        String result = doctorService.removeSpecialization(doctorId, specializationId);

        if (result.equals("The doctor with that id does not exist")
                || result.equals("That specialization does not exist")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        }

        if (result.equals("The doctor does not have that specialization")) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(result);
        }

        return ResponseEntity.ok(result);
    }

    @PatchMapping("/{doctorId}/office")
    public ResponseEntity<?> changeOffice(
            @PathVariable UUID doctorId,
            @RequestParam String officeNumber) {

        String result = doctorService.changeOffice(doctorId, officeNumber);

        if (result.equals("The doctor with that id does not exist")
                || result.equals("The office with that office number does not exist")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        }

        if (result.equals("That office is taken by other doctor")) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(result);
        }

        return ResponseEntity.ok(result);
    }

    @GetMapping("/{doctorId}/agenda")
    public ResponseEntity<?> getDoctorAgenda(
            @PathVariable UUID doctorId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        if (doctorService.getDoctorById(doctorId) == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("The doctor with that id does not exist");
        }

        List<Appointment> appointments = doctorService.getDoctorAgenda(doctorId, date);

        return ResponseEntity.ok(appointments);
    }

    @GetMapping("/search")
    public List<Doctor> searchDoctors(@RequestParam String name) {
        return doctorService.searchDoctorsByName(name);
    }
}
