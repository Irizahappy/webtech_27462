package auca.ac.clinicsystem.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import auca.ac.clinicsystem.model.Specialization;
import auca.ac.clinicsystem.service.SpecializationService;

@RestController
@RequestMapping("/api/specializations")
public class SpecializationController {

    @Autowired
    private SpecializationService specializationService;

    @GetMapping
    public List<Specialization> getAllSpecializations() {
        return specializationService.getAllSpecializations();
    }

    @GetMapping("/unused")
    public List<Specialization> findUnusedSpecializations() {
        return specializationService.findUnusedSpecializations();
    }

    @GetMapping("/{id}")
    public Specialization getSpecializationById(@PathVariable UUID id) {
        return specializationService.getSpecializationById(id);
    }

    @PostMapping
    public Specialization createSpecialization(@RequestBody Specialization specialization) {
        return specializationService.createSpecialization(specialization);
    }

    @PutMapping("/{id}")
    public Specialization updateSpecialization(
            @PathVariable UUID id,
            @RequestBody Specialization specialization) {

        return specializationService.updateSpecialization(id, specialization);
    }

    @DeleteMapping("/{id}")
    public void deleteSpecialization(@PathVariable UUID id) {
        specializationService.deleteSpecialization(id);
    }
}