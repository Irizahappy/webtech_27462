package auca.ac.clinicsystem.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import auca.ac.clinicsystem.model.Specialization;

public interface SpecializationRepository extends JpaRepository<Specialization, UUID> {

    @Query("""
            select s
            from Specialization s
            where s.doctors is empty
            """)
    List<Specialization> findUnusedSpecializations();
}