
package auca.ac.clinicsystem.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import auca.ac.clinicsystem.model.Appointment;
import auca.ac.clinicsystem.model.AppointmentStatus;

public interface AppointmentRepository extends JpaRepository<Appointment, UUID> {

    List<Appointment> findByStatusOrderByAppointmentDateAsc(
            AppointmentStatus status
    );

    List<Appointment> findByDoctorIdAndStatusOrderByAppointmentDateAsc(
            UUID doctorId,
            AppointmentStatus status
    );

    List<Appointment> findByAppointmentDateBetweenOrderByAppointmentDateAsc(
            LocalDate start,
            LocalDate end
    );

    boolean existsByDoctorIdAndAppointmentDateAndStatusNot(
            UUID doctorId,
            LocalDate appointmentDate,
            AppointmentStatus status
    );

    boolean existsByDoctorIdAndAppointmentDateAndStatusNotAndIdNot(
            UUID doctorId,
            LocalDate appointmentDate,
            AppointmentStatus status,
            UUID appointmentId
    );

    List<Appointment> findByDoctorIdAndAppointmentDateAndStatusNotOrderByAppointmentDateAsc(
            UUID doctorId,
            LocalDate appointmentDate,
            AppointmentStatus status
    );

    List<Appointment> findByPatientSsNumberAndAppointmentDateGreaterThanEqualAndStatusInOrderByAppointmentDateAsc(
            String ssNumber,
            LocalDate date,
            List<AppointmentStatus> statuses
    );

    long countByAppointmentDate(LocalDate appointmentDate);

    long countByStatus(AppointmentStatus status);

    @Query("SELECT p.firstName, d.firstName, a.appointmentDate " +
           "FROM Appointment a " +
           "JOIN a.patient p " +
           "JOIN a.doctor d " +
           "WHERE a.status = :status AND a.appointmentDate < :today " +
           "ORDER BY a.appointmentDate ASC")
    List<Object[]> findOverdueByStatus(
            @Param("status") AppointmentStatus status,
            @Param("today") LocalDate today
    );

    @Query("SELECT DISTINCT a FROM Appointment a " +
           "JOIN a.doctor d " +
           "JOIN d.specializations s " +
           "WHERE s.name = :specializationName " +
           "ORDER BY a.appointmentDate ASC")
    List<Appointment> findByDoctorSpecializationName(
            @Param("specializationName") String specializationName
    );

    @Query("SELECT a.status, COUNT(a) " +
           "FROM Appointment a " +
           "GROUP BY a.status")
    List<Object[]> countAppointmentsByStatus();

    @Modifying
    @Query("UPDATE Appointment a " +
           "SET a.status = :cancelledStatus " +
           "WHERE a.doctor.id = :doctorId " +
           "AND a.appointmentDate = :date " +
           "AND a.status <> :completedStatus")
    int cancelAppointmentsForDay(
            @Param("doctorId") UUID doctorId,
            @Param("date") LocalDate date,
            @Param("cancelledStatus") AppointmentStatus cancelledStatus,
            @Param("completedStatus") AppointmentStatus completedStatus
    );
}
