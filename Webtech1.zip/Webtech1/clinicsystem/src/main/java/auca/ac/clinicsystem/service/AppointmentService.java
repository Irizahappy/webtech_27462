
package auca.ac.clinicsystem.service;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import auca.ac.clinicsystem.model.Appointment;
import auca.ac.clinicsystem.model.AppointmentStatus;
import auca.ac.clinicsystem.model.Doctor;
import auca.ac.clinicsystem.model.Patient;
import auca.ac.clinicsystem.repository.AppointmentRepository;
import auca.ac.clinicsystem.repository.DoctorRepository;
import auca.ac.clinicsystem.repository.PatientRepository;
import auca.ac.clinicsystem.repository.PrescriptionRepository;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private PrescriptionRepository prescriptionRepository;

    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    public Appointment getAppointmentById(UUID id) {
        return appointmentRepository.findById(id).orElse(null);
    }

    public Appointment createAppointment(
            UUID doctorId,
            UUID patientId,
            LocalDate appointmentDate,
            String reason,
            AppointmentStatus status) {

        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);

        if (doctor == null) {
            return null;
        }

        Patient patient = patientRepository.findById(patientId).orElse(null);

        if (patient == null) {
            return null;
        }

        if (appointmentDate == null || appointmentDate.isBefore(LocalDate.now())) {
            return null;
        }

        boolean doctorBooked =
                appointmentRepository.existsByDoctorIdAndAppointmentDateAndStatusNot(
                        doctorId,
                        appointmentDate,
                        AppointmentStatus.CANCELLED
                );

        if (doctorBooked) {
            return null;
        }

        Appointment appointment = new Appointment();
        appointment.setDoctor(doctor);
        appointment.setPatient(patient);
        appointment.setAppointmentDate(appointmentDate);
        appointment.setReason(reason);
        appointment.setStatus(AppointmentStatus.SCHEDULED);

        return appointmentRepository.save(appointment);
    }

    public String saveAppointment(Appointment appointment) {

        if (appointment.getAppointmentDate() == null
                || appointment.getAppointmentDate().isBefore(LocalDate.now())) {
            return "Appointment date cannot be in the past";
        }

        if (appointment.getDoctor() == null
                || appointment.getDoctor().getId() == null
                || !doctorRepository.existsById(appointment.getDoctor().getId())) {
            return "The doctor with that id does not exist";
        }

        if (appointment.getPatient() == null
                || appointment.getPatient().getId() == null
                || !patientRepository.existsById(appointment.getPatient().getId())) {
            return "The patient with that id does not exist";
        }

        boolean doctorBooked =
                appointmentRepository.existsByDoctorIdAndAppointmentDateAndStatusNot(
                        appointment.getDoctor().getId(),
                        appointment.getAppointmentDate(),
                        AppointmentStatus.CANCELLED
                );

        if (doctorBooked) {
            return "Doctor is already booked on that date";
        }

        appointment.setId(null);
        appointment.setStatus(AppointmentStatus.SCHEDULED);

        appointmentRepository.save(appointment);

        return "Appointment saved successfully";
    }

    public String updateAppointment(
            UUID id,
            LocalDate appointmentDate,
            String reason,
            AppointmentStatus status) {

        Appointment appointment = appointmentRepository.findById(id).orElse(null);

        if (appointment == null) {
            return "The appointment with that id does not exist";
        }

        if (appointmentDate == null
                || appointmentDate.isBefore(LocalDate.now())) {
            return "Appointment date cannot be in the past";
        }

        boolean doctorBooked =
                appointmentRepository.existsByDoctorIdAndAppointmentDateAndStatusNotAndIdNot(
                        appointment.getDoctor().getId(),
                        appointmentDate,
                        AppointmentStatus.CANCELLED,
                        id
                );

        if (doctorBooked) {
            return "Doctor is already booked on that date";
        }

        appointment.setAppointmentDate(appointmentDate);
        appointment.setReason(reason);

        appointmentRepository.save(appointment);

        return "Appointment updated successfully";
    }

    public String changeAppointmentStatus(UUID id, AppointmentStatus newStatus) {

        Appointment appointment = appointmentRepository.findById(id).orElse(null);

        if (appointment == null) {
            return "The appointment with that id does not exist";
        }

        AppointmentStatus currentStatus = appointment.getStatus();

        boolean allowed = false;

        if (currentStatus == AppointmentStatus.SCHEDULED) {
            allowed = newStatus == AppointmentStatus.CONFIRMED
                    || newStatus == AppointmentStatus.CANCELLED;
        } else if (currentStatus == AppointmentStatus.CONFIRMED) {
            allowed = newStatus == AppointmentStatus.COMPLETED
                    || newStatus == AppointmentStatus.CANCELLED;
        }

        if (!allowed) {
            return "Cannot change status from " + currentStatus + " to " + newStatus;
        }

        appointment.setStatus(newStatus);
        appointmentRepository.save(appointment);

        return "Appointment status updated successfully";
    }

    public String rescheduleAppointment(UUID id, LocalDate newDate) {

        Appointment appointment = appointmentRepository.findById(id).orElse(null);

        if (appointment == null) {
            return "The appointment with that id does not exist";
        }

        if (appointment.getStatus() == AppointmentStatus.COMPLETED
                || appointment.getStatus() == AppointmentStatus.CANCELLED) {
            return "A " + appointment.getStatus()
                    + " appointment cannot be rescheduled";
        }

        if (newDate == null || newDate.isBefore(LocalDate.now())) {
            return "Appointment date cannot be in the past";
        }

        boolean doctorBooked =
                appointmentRepository.existsByDoctorIdAndAppointmentDateAndStatusNotAndIdNot(
                        appointment.getDoctor().getId(),
                        newDate,
                        AppointmentStatus.CANCELLED,
                        id
                );

        if (doctorBooked) {
            return "Doctor is already booked on that date";
        }

        appointment.setAppointmentDate(newDate);
        appointment.setStatus(AppointmentStatus.SCHEDULED);

        appointmentRepository.save(appointment);

        return "Appointment rescheduled successfully";
    }

    public String deleteAppointment(UUID id) {

        if (!appointmentRepository.existsById(id)) {
            return "The appointment with that id does not exist";
        }

        if (prescriptionRepository.existsByAppointmentId(id)) {
            return "That appointment has prescriptions, delete them first";
        }

        appointmentRepository.deleteById(id);

        return "Appointment deleted successfully";
    }

    public List<Appointment> getAppointmentsByStatus(AppointmentStatus status) {
        return appointmentRepository.findByStatusOrderByAppointmentDateAsc(status);
    }

    public List<Appointment> findBetween(LocalDate start, LocalDate end) {
        return appointmentRepository
                .findByAppointmentDateBetweenOrderByAppointmentDateAsc(start, end);
    }

    public List<Appointment> getScheduledAppointmentsOfDoctor(UUID doctorId) {
        return appointmentRepository
                .findByDoctorIdAndStatusOrderByAppointmentDateAsc(
                        doctorId,
                        AppointmentStatus.SCHEDULED
                );
    }

    public List<Object[]> getOverdueScheduledAppointments() {
        return appointmentRepository.findOverdueByStatus(
                AppointmentStatus.SCHEDULED,
                LocalDate.now()
        );
    }

    public List<Appointment> getAppointmentsBySpecialization(String specializationName) {
        return appointmentRepository.findByDoctorSpecializationName(specializationName);
    }

    public List<Object[]> getAppointmentStatsByStatus() {
        return appointmentRepository.countAppointmentsByStatus();
    }

    @Transactional
    public String cancelAppointmentsForDay(UUID doctorId, LocalDate date) {

        int cancelled = appointmentRepository.cancelAppointmentsForDay(
                doctorId,
                date,
                AppointmentStatus.CANCELLED,
                AppointmentStatus.COMPLETED
        );

        return cancelled + " appointments cancelled";
    }
}
