
package auca.ac.clinicsystem.service;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import auca.ac.clinicsystem.model.Appointment;
import auca.ac.clinicsystem.model.AppointmentStatus;
import auca.ac.clinicsystem.model.Prescription;
import auca.ac.clinicsystem.repository.AppointmentRepository;
import auca.ac.clinicsystem.repository.PatientRepository;
import auca.ac.clinicsystem.repository.PrescriptionRepository;

@Service
public class PrescriptionService {

    @Autowired
    private PrescriptionRepository prescriptionRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private PatientRepository patientRepository;

    public String savePrescription(UUID appointmentId, Prescription prescription) {

        Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);

        if (appointment == null) {
            return "The appointment with that id does not exist";
        }

        if (appointment.getStatus() != AppointmentStatus.COMPLETED) {
            return "Prescription can only be issued for a COMPLETED appointment";
        }

        prescription.setId(null);
        prescription.setAppointment(appointment);
        prescription.setIssuedDate(LocalDate.now());

        prescriptionRepository.save(prescription);

        return "Prescription saved successfully";
    }

    public List<Prescription> getPrescriptionsByAppointment(UUID appointmentId) {
        return prescriptionRepository.findByAppointmentId(appointmentId);
    }

    public boolean appointmentExists(UUID appointmentId) {
        return appointmentRepository.existsById(appointmentId);
    }

    public List<Prescription> getPrescriptionsByPatient(String ssNumber) {
        return prescriptionRepository.findByPatientSsNumber(ssNumber);
    }

    public boolean patientExists(String ssNumber) {
        return patientRepository.existsBySsNumber(ssNumber);
    }

    public String updatePrescription(UUID id, Prescription updatedPrescription) {

        Prescription prescription = prescriptionRepository.findById(id).orElse(null);

        if (prescription == null) {
            return "The prescription with that id does not exist";
        }

        prescription.setMedicineName(updatedPrescription.getMedicineName());
        prescription.setDosage(updatedPrescription.getDosage());
        prescription.setDurationDays(updatedPrescription.getDurationDays());

        prescriptionRepository.save(prescription);

        return "Prescription updated successfully";
    }

    public String deletePrescription(UUID id) {

        if (!prescriptionRepository.existsById(id)) {
            return "The prescription with that id does not exist";
        }

        prescriptionRepository.deleteById(id);

        return "Prescription deleted successfully";
    }
}
