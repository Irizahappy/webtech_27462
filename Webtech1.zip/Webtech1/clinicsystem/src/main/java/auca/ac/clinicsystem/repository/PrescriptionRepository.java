
package auca.ac.clinicsystem.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import auca.ac.clinicsystem.model.Prescription;

public interface PrescriptionRepository extends JpaRepository<Prescription, UUID> {

    List<Prescription> findByAppointmentId(UUID appointmentId);

    boolean existsByAppointmentId(UUID appointmentId);

    @Query("SELECT p FROM Prescription p " +
           "JOIN p.appointment a " +
           "JOIN a.patient pt " +
           "WHERE pt.ssNumber = :ssNumber " +
           "ORDER BY p.issuedDate DESC")
    List<Prescription> findByPatientSsNumber(
            @Param("ssNumber") String ssNumber
    );
}
