
package auca.ac.clinicsystem.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import auca.ac.clinicsystem.model.Office;
import auca.ac.clinicsystem.service.OfficeService;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/api/offices")
public class OfficeController {

    @Autowired
    private OfficeService officeService;

    @GetMapping
    public List<Office> getAllOffices() {
        return officeService.getAllOffices();
    }

    @GetMapping("/busiest")
    public Object getBusiestOffice() {
        return officeService.getBusiestOffice();
    }

    @GetMapping("/free")
    public List<Office> findFreeOffices() {
        return officeService.findFreeOffices();
    }

    @GetMapping("/{id}")
    public Office getOfficeById(@PathVariable UUID id) {
        return officeService.getOfficeById(id);
    }

    @PostMapping
    public Office createOffice(@RequestBody Office office) {
        return officeService.createOffice(office);
    }

    @PutMapping("/{id}")
    public Office updateOffice(
            @PathVariable UUID id,
            @RequestBody Office office) {

        return officeService.updateOffice(id, office);
    }

    @DeleteMapping("/{id}")
    public void deleteOffice(@PathVariable UUID id) {
        officeService.deleteOffice(id);
    }


@DeleteMapping("/number/{officeNumber}")
public String deleteOfficeByOfficeNumber(
        @PathVariable String officeNumber) {

    officeService.deleteOfficeByOfficeNumber(officeNumber);

    return "Office deleted successfully";
}

}
