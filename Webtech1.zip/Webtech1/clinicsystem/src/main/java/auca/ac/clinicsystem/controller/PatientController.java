
package auca.ac.clinicsystem.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import auca.ac.clinicsystem.model.Appointment;
import auca.ac.clinicsystem.model.Patient;
import auca.ac.clinicsystem.service.PatientService;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    @Autowired
    private PatientService patientService;

    @GetMapping
    public List<Patient> getAllPatients() {
        return patientService.getAllPatients();
    }

    @GetMapping("/by-last-name")
    public List<Patient> findByLastName(@RequestParam String lastName) {
        return patientService.findByLastName(lastName);
    }

    @GetMapping("/of-doctor/{doctorId}")
    public ResponseEntity<?> findPatientsOfDoctor(@PathVariable UUID doctorId) {

        Object result = patientService.findPatientsOfDoctor(doctorId);

        if (result instanceof String) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(result);
        } else {
            return ResponseEntity.ok(result);
        }
    }

    @GetMapping("/frequent")
    public List<Patient> findFrequentPatients(@RequestParam long min) {
        return patientService.findFrequentPatients(min);
    }

    @GetMapping("/{ssNumber}/upcoming")
    public ResponseEntity<?> getUpcomingAppointments(@PathVariable String ssNumber) {

        if (!patientService.patientExists(ssNumber)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("The patient with that SS number does not exist");
        }

        List<Appointment> appointments = patientService.getUpcomingAppointments(ssNumber);

        return ResponseEntity.ok(appointments);
    }

    @GetMapping("/{id}")
    public Patient getPatientById(@PathVariable UUID id) {
        return patientService.getPatientById(id);
    }

    @PostMapping
    public Patient createPatient(@RequestBody Patient patient) {
        return patientService.createPatient(patient);
    }

    @PutMapping("/{id}")
    public Patient updatePatient(
            @PathVariable UUID id,
            @RequestBody Patient patient) {

        return patientService.updatePatient(id, patient);
    }

    @DeleteMapping("/{id}")
    public void deletePatient(@PathVariable UUID id) {
        patientService.deletePatient(id);
    }
}
