
package auca.ac.clinicsystem.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import auca.ac.clinicsystem.model.Prescription;
import auca.ac.clinicsystem.service.PrescriptionService;

@RestController
@RequestMapping("/api/prescriptions")
public class PrescriptionController {

    @Autowired
    private PrescriptionService prescriptionService;

    @PostMapping("/save")
    public ResponseEntity<String> savePrescription(
            @RequestParam UUID appointmentId,
            @RequestBody Prescription prescription) {

        String result = prescriptionService.savePrescription(appointmentId, prescription);

        if (result.equals("The appointment with that id does not exist")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        } else if (result.equals("Prescription can only be issued for a COMPLETED appointment")) {
            return ResponseEntity.badRequest().body(result);
        } else {
            return ResponseEntity.status(HttpStatus.CREATED).body(result);
        }
    }

    @GetMapping("/appointment/{appointmentId}")
    public ResponseEntity<?> getPrescriptionsByAppointment(@PathVariable UUID appointmentId) {

        if (!prescriptionService.appointmentExists(appointmentId)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("The appointment with that id does not exist");
        }

        List<Prescription> prescriptions =
                prescriptionService.getPrescriptionsByAppointment(appointmentId);

        return ResponseEntity.ok(prescriptions);
    }

    @GetMapping("/patient/{ssNumber}")
    public ResponseEntity<?> getPrescriptionsByPatient(@PathVariable String ssNumber) {

        if (!prescriptionService.patientExists(ssNumber)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("The patient with that SS number does not exist");
        }

        List<Prescription> prescriptions =
                prescriptionService.getPrescriptionsByPatient(ssNumber);

        return ResponseEntity.ok(prescriptions);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updatePrescription(
            @PathVariable UUID id,
            @RequestBody Prescription prescription) {

        String result = prescriptionService.updatePrescription(id, prescription);

        if (result.equals("The prescription with that id does not exist")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        } else {
            return ResponseEntity.ok(result);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deletePrescription(@PathVariable UUID id) {

        String result = prescriptionService.deletePrescription(id);

        if (result.equals("The prescription with that id does not exist")) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        } else {
            return ResponseEntity.ok(result);
        }
    }
}
