package auca.ac.clinicsystem.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import auca.ac.clinicsystem.model.Specialization;
import auca.ac.clinicsystem.repository.SpecializationRepository;

@Service
public class SpecializationService {

    @Autowired
    private SpecializationRepository specializationRepository;

    public List<Specialization> getAllSpecializations() {
        return specializationRepository.findAll();
    }

    public Specialization getSpecializationById(UUID id) {
        return specializationRepository.findById(id).orElse(null);
    }

    public Specialization createSpecialization(Specialization specialization) {
        return specializationRepository.save(specialization);
    }

    public Specialization updateSpecialization(UUID id, Specialization updatedSpecialization) {
        Specialization specialization = specializationRepository.findById(id).orElse(null);

        if (specialization == null) {
            return null;
        }

        specialization.setName(updatedSpecialization.getName());

        return specializationRepository.save(specialization);
    }

    public void deleteSpecialization(UUID id) {
        specializationRepository.deleteById(id);
    }

    public List<Specialization> findUnusedSpecializations() {
        return specializationRepository.findUnusedSpecializations();
    }
}